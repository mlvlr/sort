using sortirovkarascheskoi;
using System.Security;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test54321()
        {
            string input = "5 4 3 2 1";
            string output = "1 2 3 4 5";

            Sorted sorted = new Sorted();
            string result = sorted.Sort(input);
            Assert.AreEqual(output, result);
        }

        [TestMethod]
        public void Test12345()
        {
            string input = "1 2 3 4 5";
            string output = "1 2 3 4 5";

            Sorted sorted = new Sorted();
            string result = sorted.Sort(input);
            Assert.AreEqual(output, result);
        }

        [TestMethod]
        public void Test_5_4_3()
        {
            string input = "5 4 3 2 1 0 -1 -2 -3 -4 -5";
            string output = "-5 -4 -3 -2 -1 0 1 2 3 4 5";

            Sorted sorted = new Sorted();
            string result = sorted.Sort(input);
            Assert.AreEqual(output, result);
        }

        [TestMethod]
        public void Testreg()
        {
            bool Autorizated = false;
            string Login = "user";
            string Password = "123";
            DBManager dBManager = new DBManager("..\\..\\..\\..\\users.db");
            Assert.AreEqual(Autorizated, dBManager.CheckUser(Login, Password));

        }

    }
}