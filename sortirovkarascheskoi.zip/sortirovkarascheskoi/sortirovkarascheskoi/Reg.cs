﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sortirovkarascheskoi
{
    public partial class Reg : Form
    {
        public Reg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBManager dbManager = new DBManager("..\\..\\..\\..\\users.db");
            

            if (RegLogin.Text == "" || RegPwd.Text == "")
            {
                MessageBox.Show("Одно из обязательных полей не заполнено!");
            }
            else
            {
                if (RegPwd.Text == RegPwd2.Text)
                {
                    if (dbManager.AddUser(RegLogin.Text, RegPwd.Text) == true)
                    {
                        MessageBox.Show("Успешно!");
                    }
                    else
                    {
                        MessageBox.Show("Не удалось!");
                    }
                }
                else
                {
                    MessageBox.Show("Пароли не совпадают!");
                }
            }

            
            dbManager.CloseConnection();
        }

    }
}
